﻿using Snowflake.Data.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureFunctionSnowflakeIntegration.Services
{
    static class OAuthConnect
    {
        public static IDbConnection ConnectWithSnowFlake()
        {
            IDbConnection conn = new SnowflakeDbConnection();
            conn.ConnectionString = "account=dhptaty-zx88498;user=Samiranadak;password=Dev@2023;db=MYDB;schema=MYSCHEMA;warehouse=COMPUTE_WH";
            return conn;
        }
    }
}
