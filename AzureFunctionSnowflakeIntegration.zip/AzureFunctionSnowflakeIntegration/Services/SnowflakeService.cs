﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureFunctionSnowflakeIntegration.Services
{
    public class SnowflakeService : ISnowflakeService
    {
        public readonly IDbConnection snowflakeServiceClient;
        public SnowflakeService()
        {
            snowflakeServiceClient = OAuthConnect.ConnectWithSnowFlake();
        }

        public async Task<List<Dictionary<string, object>>> GetAllContactsFromSnowflake(string query)
        {
            var rows = new List<Dictionary<string, object>>();
            try
            {
                snowflakeServiceClient.Open();
                IDbCommand cmd = snowflakeServiceClient.CreateCommand();
                //cmd.CommandText = $"select  * from MYSCHEMA.EMPLOYEE";
                cmd.CommandText = query;
                var reader = cmd.ExecuteReader();

                
                var columns1  = Enumerable.Range(0, reader.FieldCount).Select(reader.GetName).ToList(); 
                //Func<IDataReader, IList<string>> GetColumns = rdr =>
                //{
                //    var cols = new List<string>();
                //    for (var i = 0; i < reader.FieldCount; i++)
                //    {
                //        cols.Add(reader.GetString(i));
                //    }
                //    return cols;
                //};

                //var columns = GetColumns(reader);

                while (reader.Read())
                {
                    rows.Add(columns1.ToDictionary(column => column, column => reader[column]));
                }
                

                snowflakeServiceClient.Close();
                
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return rows;
        }
        public async Task<string> InsertContactIntoSnowflake()
        {
            snowflakeServiceClient.Open();
            for (int i = 9747; i <= 15000; i++)
            {
                var firstName = "Samiran"+i.ToString();
                var lastName = "Adak"+i.ToString();
                var address = "Kolkata"+i.ToString();

                IDbCommand cmd = snowflakeServiceClient.CreateCommand();
                cmd.CommandText = $"insert into MYSCHEMA.EMPLOYEE(firstName,lastName,address) values('{firstName}','{lastName}','{address}')";
                var reader = cmd.ExecuteReader();
            }

            

            snowflakeServiceClient.Close();
            return "Inserted Successfully";
        }

    }
}
