﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureFunctionSnowflakeIntegration.Services
{
    public  interface ISnowflakeService
    {
        Task<List<Dictionary<string, object>>> GetAllContactsFromSnowflake(string query);
        Task<string> InsertContactIntoSnowflake();
    }
}
